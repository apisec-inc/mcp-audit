MCP Audit CLI
=============

A command-line tool to discover and audit MCP (Model Context Protocol) servers.

INSTALLATION
------------
1. Make sure you have Python 3.9 or higher installed
   Check with: python --version

2. Open Terminal (Mac) or Command Prompt (Windows)

3. Navigate to this folder:
   cd mcp-audit-cli

4. Install the tool:
   pip install -e .

5. Run a scan:
   mcp-audit scan

COMMANDS
--------
mcp-audit scan              # Scan your machine for MCPs
mcp-audit scan --verbose    # Detailed output
mcp-audit registry          # View known MCP registry
mcp-audit registry stats    # Registry statistics
mcp-audit --help            # All options

TROUBLESHOOTING
---------------
- If "mcp-audit" is not found, try: python -m mcp_audit.cli scan
- On Mac, you may need to use pip3 instead of pip
- Make sure Python is added to your PATH

For more help, see the docs/ folder or run: mcp-audit --help
