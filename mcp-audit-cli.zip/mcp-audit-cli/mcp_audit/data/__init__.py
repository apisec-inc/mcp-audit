"""
MCP Audit Data - Known MCP registry and lookups
"""

import json
from pathlib import Path
from typing import Optional

_registry = None


def get_registry() -> dict:
    """Load and cache the known MCP registry"""
    global _registry
    if _registry is None:
        registry_path = Path(__file__).parent / "known_mcps.json"
        _registry = json.loads(registry_path.read_text())
    return _registry


def lookup_mcp(source: str) -> Optional[dict]:
    """Look up an MCP by package name or source string"""
    registry = get_registry()
    source_lower = source.lower()

    for mcp in registry["mcps"]:
        if mcp["package"].lower() in source_lower:
            return mcp
        if mcp.get("endpoint") and mcp["endpoint"].lower() in source_lower:
            return mcp

    return None


def get_mcps_by_provider(provider: str) -> list[dict]:
    """Get all MCPs from a specific provider"""
    registry = get_registry()
    return [m for m in registry["mcps"] if m["provider"].lower() == provider.lower()]


def get_mcps_by_risk(risk_level: str) -> list[dict]:
    """Get all MCPs with a specific risk level"""
    registry = get_registry()
    return [m for m in registry["mcps"] if m["risk_level"] == risk_level]


def get_verified_mcps() -> list[dict]:
    """Get all verified MCPs"""
    registry = get_registry()
    return [m for m in registry["mcps"] if m.get("verified", False)]


def get_all_endpoints() -> list[dict]:
    """Get all MCPs with known endpoints (for network monitoring)"""
    registry = get_registry()
    return [m for m in registry["mcps"] if m.get("endpoint")]


def get_risk_definition(risk_level: str) -> str:
    """Get the definition for a risk level"""
    registry = get_registry()
    return registry.get("risk_definitions", {}).get(risk_level, "Unknown risk level")


def get_type_definition(mcp_type: str) -> str:
    """Get the definition for an MCP type"""
    registry = get_registry()
    return registry.get("type_definitions", {}).get(mcp_type, "Unknown type")
