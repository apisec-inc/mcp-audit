"""
MCP Audit Output Formatters
"""
